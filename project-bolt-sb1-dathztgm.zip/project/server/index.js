import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { products } from './data/products.js';

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage (replace with real database in production)
const users = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    password: bcrypt.hashSync('password123', 10),
  }
];

const chatSessions = [];

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Auth routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Create new user
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = {
      id: uuidv4(),
      name,
      email,
      password: hashedPassword,
    };

    users.push(user);

    // Generate token
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Generate token
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Chat routes
app.post('/api/chat', authenticateToken, async (req, res) => {
  try {
    const { message } = req.body;
    const userId = req.user.userId;

    // Process the message and generate response
    const response = await processMessage(message);

    // Save to chat session (in production, save to database)
    const chatMessage = {
      id: uuidv4(),
      userId,
      message,
      response: response.message,
      products: response.products,
      timestamp: new Date(),
    };

    chatSessions.push(chatMessage);

    res.json(response);
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Product search function
const searchProducts = (query, category = null, maxResults = 5) => {
  const searchTerms = query.toLowerCase().split(' ');
  
  let filteredProducts = products;
  
  if (category) {
    filteredProducts = filteredProducts.filter(p => 
      p.category.toLowerCase() === category.toLowerCase()
    );
  }

  const scoredProducts = filteredProducts.map(product => {
    let score = 0;
    const searchText = `${product.name} ${product.description} ${product.brand} ${product.category} ${product.features.join(' ')}`.toLowerCase();
    
    searchTerms.forEach(term => {
      if (searchText.includes(term)) {
        score += 1;
      }
      if (product.name.toLowerCase().includes(term)) {
        score += 2; // Higher weight for name matches
      }
    });
    
    return { ...product, score };
  });

  return scoredProducts
    .filter(p => p.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, maxResults);
};

// Message processing function
const processMessage = async (message) => {
  const lowerMessage = message.toLowerCase();
  
  // Greeting responses
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return {
      message: "Hello! I'm here to help you find the perfect electronics. What are you looking for today?",
      products: []
    };
  }

  // Category-specific searches
  if (lowerMessage.includes('laptop') || lowerMessage.includes('computer')) {
    const laptops = searchProducts(message, 'laptops');
    return {
      message: `I found ${laptops.length} great laptops for you! Here are some top recommendations:`,
      products: laptops
    };
  }

  if (lowerMessage.includes('phone') || lowerMessage.includes('smartphone')) {
    const phones = searchProducts(message, 'smartphones');
    return {
      message: `Here are some excellent smartphones that match your needs:`,
      products: phones
    };
  }

  if (lowerMessage.includes('headphone') || lowerMessage.includes('audio') || lowerMessage.includes('music')) {
    const audio = searchProducts(message, 'audio');
    return {
      message: `I found some amazing audio devices for you:`,
      products: audio
    };
  }

  if (lowerMessage.includes('gaming') || lowerMessage.includes('game')) {
    const gaming = searchProducts(message, 'gaming');
    return {
      message: `Check out these gaming essentials:`,
      products: gaming
    };
  }

  if (lowerMessage.includes('smart home') || lowerMessage.includes('home automation')) {
    const smartHome = searchProducts(message, 'smart home');
    return {
      message: `Here are some smart home devices to enhance your living space:`,
      products: smartHome
    };
  }

  // Price-based searches
  if (lowerMessage.includes('cheap') || lowerMessage.includes('budget') || lowerMessage.includes('affordable')) {
    const budgetProducts = products
      .filter(p => p.price < 500)
      .sort((a, b) => a.price - b.price)
      .slice(0, 5);
    
    return {
      message: "Here are some great budget-friendly options:",
      products: budgetProducts
    };
  }

  if (lowerMessage.includes('premium') || lowerMessage.includes('high-end') || lowerMessage.includes('expensive')) {
    const premiumProducts = products
      .filter(p => p.price > 1000)
      .sort((a, b) => b.price - a.price)
      .slice(0, 5);
    
    return {
      message: "Here are some premium, high-end products:",
      products: premiumProducts
    };
  }

  // General search
  const searchResults = searchProducts(message);
  
  if (searchResults.length > 0) {
    return {
      message: `I found ${searchResults.length} products that match your search:`,
      products: searchResults
    };
  }

  // Default response
  return {
    message: "I'd be happy to help you find the right electronics! Try asking about specific products like laptops, smartphones, headphones, or gaming equipment. You can also ask about budget-friendly or premium options.",
    products: []
  };
};

// Get products endpoint
app.get('/api/products', authenticateToken, (req, res) => {
  const { category, search, limit = 20 } = req.query;
  
  let filteredProducts = products;
  
  if (category) {
    filteredProducts = filteredProducts.filter(p => 
      p.category.toLowerCase() === category.toLowerCase()
    );
  }
  
  if (search) {
    filteredProducts = searchProducts(search, category, limit);
  }
  
  res.json(filteredProducts.slice(0, limit));
});

// Get categories endpoint
app.get('/api/categories', authenticateToken, (req, res) => {
  const categories = [...new Set(products.map(p => p.category))];
  res.json(categories);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});