import React from 'react';
import { Star, ShoppingCart, Eye } from 'lucide-react';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
  compact?: boolean;
  onViewDetails?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  compact = false,
  onViewDetails 
}) => {
  const handleViewDetails = () => {
    if (onViewDetails) {
      onViewDetails(product);
    }
  };

  return (
    <div className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow ${
      compact ? 'p-3' : 'p-4'
    }`}>
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className={`w-full object-cover rounded-lg ${
            compact ? 'h-32' : 'h-48'
          }`}
        />
        {!product.inStock && (
          <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs">
            Out of Stock
          </div>
        )}
        {product.originalPrice && (
          <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs">
            Sale
          </div>
        )}
      </div>

      <div className={`${compact ? 'mt-2' : 'mt-4'}`}>
        <h3 className={`font-semibold text-gray-800 ${
          compact ? 'text-sm' : 'text-lg'
        } line-clamp-2`}>
          {product.name}
        </h3>
        
        <p className={`text-gray-600 ${
          compact ? 'text-xs mt-1' : 'text-sm mt-2'
        } line-clamp-2`}>
          {product.description}
        </p>

        <div className={`flex items-center ${compact ? 'mt-1' : 'mt-2'}`}>
          <div className="flex items-center">
            <Star className="w-4 h-4 text-yellow-400 fill-current" />
            <span className="text-sm text-gray-600 ml-1">
              {product.rating} ({product.reviews})
            </span>
          </div>
          <span className={`text-xs text-gray-500 ml-2 ${compact ? 'hidden' : ''}`}>
            {product.brand}
          </span>
        </div>

        <div className={`flex items-center justify-between ${
          compact ? 'mt-2' : 'mt-4'
        }`}>
          <div className="flex items-center space-x-2">
            <span className={`font-bold text-gray-900 ${
              compact ? 'text-sm' : 'text-lg'
            }`}>
              ${product.price}
            </span>
            {product.originalPrice && (
              <span className={`text-gray-500 line-through ${
                compact ? 'text-xs' : 'text-sm'
              }`}>
                ${product.originalPrice}
              </span>
            )}
          </div>
          
          <div className="flex space-x-2">
            {onViewDetails && (
              <button
                onClick={handleViewDetails}
                className="text-blue-600 hover:text-blue-700 p-1"
              >
                <Eye className="w-4 h-4" />
              </button>
            )}
            <button
              disabled={!product.inStock}
              className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-1"
            >
              <ShoppingCart className="w-4 h-4" />
              {!compact && <span className="text-sm">Add</span>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};