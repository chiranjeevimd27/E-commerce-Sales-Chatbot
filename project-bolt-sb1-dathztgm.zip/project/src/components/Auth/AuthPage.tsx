import React, { useState } from 'react';
import { Bot, ShoppingBag } from 'lucide-react';
import { LoginForm } from './LoginForm';
import { RegisterForm } from './RegisterForm';

export const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-blue-600 p-3 rounded-full">
                <Bot className="w-8 h-8 text-white" />
              </div>
              <ShoppingBag className="w-6 h-6 text-blue-600 ml-2" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">ElectroBot</h1>
            <p className="text-gray-600">Your AI Shopping Assistant</p>
          </div>

          {isLogin ? (
            <LoginForm onToggleMode={() => setIsLogin(false)} />
          ) : (
            <RegisterForm onToggleMode={() => setIsLogin(true)} />
          )}

          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center">
              Demo credentials: admin@example.com / password123
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};